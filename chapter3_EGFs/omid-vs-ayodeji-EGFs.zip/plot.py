#!/usr/bin/env python3

# Usage: python plot_compare.py

#====Adjustable Parameters====#
xlim = (0, 500)
ylim = (-1, 1)

xticks = range(-2000, 2000, 100)
# xticks = []


figSize  = (12,3) # Size of the figure along (x, y) axis
context  = "notebook" ; # seaborn's set_context: notebook, talk, poster, paper
style    = "ticks" ; # seaborn's styles: darkgrid, whitegrid, white, ticks ... 
#=============================#

import os
import sys
from glob import glob
from obspy.core import read
from numpy import arange
import matplotlib.pyplot as plt
import seaborn as sns


for egfdir in os.listdir(os.path.abspath('.')):
    if os.path.isdir(egfdir):
        print(os.path.basename(egfdir))
        fn_omid = glob(f'{egfdir}/*.sac')
        fn_ayodeji = glob(f'{egfdir}/*.Sym')

        st = read(fn_omid[0], format='SAC')
        st += read(fn_ayodeji[0], format='SAC')
        data_omid = st[0].data
        data_ayodeji = st[1].data
        time = arange(-2000,2001,1)

        sns.set(style=style)
        sns.set_context(context)
        plt.figure(1,figSize)

        plt.plot(time, data_ayodeji, label='Kuponiyi et al., 2017', color='darkorange')
        plt.plot(time, data_omid, label='This study', color='royalblue')
        plt.xticks(xticks)
        plt.yticks([])
        plt.xlim(xlim)
        plt.ylim(ylim)
        plt.title(os.path.basename(egfdir))
        plt.legend(loc='upper right')
        plt.tight_layout()
        figout = os.path.join('.', os.path.basename(egfdir))
        plt.savefig(f"{figout}.pdf",dpi=150,transparent=True)
        plt.close()


