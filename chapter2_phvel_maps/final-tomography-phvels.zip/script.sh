#!/bin/sh
# csh plot_invdir.gmt inv_outl_9Apr/004/ .
csh plot_invdir.gmt inv_outl_9Apr/005/ .
csh plot_invdir.gmt inv_outl_9Apr/006/ .
csh plot_invdir.gmt inv_outl_9Apr/007/ .
csh plot_invdir.gmt inv_outl_9Apr/008/ .
csh plot_invdir.gmt inv_outl_9Apr/009/ .
csh plot_invdir.gmt inv_outl_9Apr/010/ .
csh plot_invdir.gmt inv_outl_9Apr/012/ .
csh plot_invdir.gmt inv_outl_9Apr/014/ .
csh plot_invdir.gmt inv_outl_9Apr/016/ .
csh plot_invdir.gmt inv_outl_9Apr/018/ .
csh plot_invdir.gmt inv_outl_9Apr/020/ .
csh plot_invdir.gmt inv_outl_9Apr/022/ .
csh plot_invdir.gmt inv_outl_9Apr/025/ .
csh plot_invdir.gmt inv_outl_9Apr/027/ .
csh plot_invdir.gmt inv_outl_9Apr/030/ .
csh plot_invdir.gmt inv_outl_9Apr/034/ .
csh plot_invdir.gmt inv_outl_9Apr/040/ .
csh plot_invdir.gmt inv_outl_9Apr/045/ .
csh plot_invdir.gmt inv_outl_9Apr/050/ .

